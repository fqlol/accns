module.exports = async client => {
  console.log(`Logged in as ${client.user.tag}!`);
  client.user.setPresence({ activity: { name: `${client.config.PREFIX}help・Plugz`, type: 'STREAMING' }, //PLAYING, STREAMING, LISTENING, WATCHING, CUSTOM_STATUS
  status: 'dnd' }); //online, idle, dnd
}